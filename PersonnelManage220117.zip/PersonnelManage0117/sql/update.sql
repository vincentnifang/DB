DELETE FROM r_base_user_dept WHERE USER_ID ='4028827e7a2d29f4017a2d80e3c00046';

INSERT INTO `r_base_user_dept`
(`USER_ID`, `DEPT_ID`, `UPDATE_TIME`, `UPDATE_VERSION`)
select
'4028827e7a2d29f4017a2d80e3c00046', DICT_ID, '2021-06-24 08:07:37', NULL
FROM
t_base_dict_tree
WHERE
DICT_NAME ='xx银行股份有限公司广州分行' AND LEAF_FLAG ='1';

