#!/bin/sh
<<!
 **********************************************************
 * Author        : zhangzm
 * Email         : zhangzm@gzcltech.com
 * Last modified : 20220531
 * Filename      : 
 * Description   : update_PersonnelManage
 * *******************************************************
!


#clrservice path
clr_path='/opt/CLRService'
#PersonnelManage_app path
PersonnelManage_app='/opt/tomcat_8088'
time=`date +"%Y%m%d"`
mkdir -p /opt/update/$time/bak
sh_path=`pwd`




function update_clr(){
    #bak
    # cp -r $clr_path/application.properties /opt/update/$time/bak
    \cp -r $clr_path/CLRService-1.0.0.jar /opt/update/$time/bak
    # \cp -r app/application.properties $clr_path/
    #stop clr_service
    clr_pid=`ps -ef |grep java |grep CLRService |awk '{print $2}'`
    if [ -n $clr_pid ];
    then
        kill -9 $clr_pid
    fi
    #clear logs
    rm -rf $clr_path/logs/*
    # has=`cat $clr_path/application.properties |grep org500`
    # org_num=`cat $clr_path/application.properties |grep httpclient.org -n |awk -F ':' '{print $1}'`
    # acc=`cat $clr_path/application.properties |grep httpclient.account |awk -F '=' '{print $2}'`
    # org=`cat $clr_path/application.properties |grep httpclient.org |awk -F '=' '{print $2}'`    

    # if [ -n "$has" ]
    # then
    #     if [ $acc != $org ]
    #     then
    #         echo 'need update'
    #         sed -i ''"$org_num"'s/'"$org"'/'"$acc"'/' $clr_path/application.properties
    #     fi
    # fi
    \cp -r app/CLRService-1.0.0.jar $clr_path  

    cd /opt/CLRService
    sh run.sh start

}


function update_PersonnelManage(){
    cd $sh_path
    #bak 
    tar -cvf /opt/update/$time/bak/PersonnelManage$time.tar $PersonnelManage_app/webapps/PersonnelManage
    # tar -cvf /opt/update/$time/bak/ODFlowable$time.tar $PersonnelManage_app/webapps/ODFlowable
    PersonnelManage_pid=`ps -ef |grep java |grep 8099 |awk '{print $2}'`
    if [ -n $PersonnelManage_pid ];
    then
        kill -9 $PersonnelManage_pid
        sleep 2
        sh $PersonnelManage_app/bin/shutdown.sh
    fi
    # rm -rf $PersonnelManage_app/webapps/PersonnelManage*
    # \cp -r $PersonnelManage_app/webapps/ODFlowable/WEB-INF/classes/application.yml app/ODFlowable/WEB-INF/classes/
    rm -rf $PersonnelManage_app/webapps/PersonnelManage/WEB-INF/lib/fastjson*
    # rm -rf $PersonnelManage_app/webapps/ODFlowable/WEB-INF/lib/log4*
    rm -rf $PersonnelManage_app/work/*

    \cp -r app/PersonnelManage/ $PersonnelManage_app/webapps
    # \cp -r app/ODFlowable $PersonnelManage_app/webapps
    # \cp -r app/applicationContext-org-task.xml $PersonnelManage_app/webapps/PersonnelManage/WEB-INF/classes/com/clkj/config/
    sh $PersonnelManage_app/bin/startup.sh

    

}
function update_sql(){
    cd $sh_path
    encryption_passwd=`cat $PersonnelManage_app/webapps/PersonnelManage/WEB-INF/classes/system.properties |grep '^password' |awk -F '=' '{print $2}'`
    for i in $encryption_passwd
    do
        passwd=`java -jar $sh_path/tools/SM4Jar.jar D $i |awk -F '：' '{print $2}'`
        mysql -uroot -p$passwd -e "exit";
        if [ $? == '0' ]
        then
            #update app
            update_PersonnelManage
            if [ $? == '0' ]
            then
                echo "update app success"
            else
                tar -xvf /opt/update/$time/bak/PersonnelManage$time.tar -C $PersonnelManage_app/webapps
            fi
            #update sql
            mysqldump -uroot -p$passwd personnel_manage > /opt/update/$time/bak/personnel_manage$time.sql
            #TRUNCATE TABLE t_clr_log;
            # mysql -uroot -p$passwd -e "TRUNCATE TABLE clr_service.t_clr_log;"
            #bak clr_service
            # mysqldump -uroot -p$passwd clr_service > /opt/update/$time/bak/clr_service$time.sql
            # sql_name=`ls $sh_path/sql`
            mysql -uroot -p$passwd personnel_manage < $sh_path/sql/personnel_manage_update.sql
            # mysql -uroot -p$passwd personnel_manage < $sh_path/sql/update.sql
            # mysql -uroot -p$passwd clr_service < $sh_path/sql/clr_service_update.sql
            if [ $? == '0' ]
            then
                echo "update sql success"
            else
                mysql -uroot -p$passwd personnel_manage < /opt/update/$time/bak/personnel_manage$time.sql
            fi
        fi 
    done
}

function check_version(){
    cd $sh_path
    #get app_name
    app_name=`pwd |rev| cut -d '/' -f 1 | rev`
    # get version
    version=`find ../ -name *$app_name*.zip |cut -d '/' -f2 |cut -d '.' -f1 |awk -F $app_name '{print $1}'`
    if [ -z $version ]
    then
        sys_path=`cat $PersonnelManage_app/webapps/PersonnelManage/WEB-INF/classes/system.properties | grep save_file_path`
        echo 'please check system.properties file save_file_path'
        echo 'because is' $sys_path        
        exit 8
    fi
    encryption_passwd=`cat $PersonnelManage_app/webapps/PersonnelManage/WEB-INF/classes/system.properties |grep '^password' |awk -F '=' '{print $2}'`
    for i in $encryption_passwd
    do
        passwd=`java -jar $sh_path/tools/SM4Jar.jar D $i |awk -F '：' '{print $2}'`
        mysql -uroot -p$passwd -e "exit";
        if [ $? == '0' ]
        then
            has_version=`mysql -uroot -p$passwd -e "select state from PersonnelManage.t_versions_file where version = '$version';" |awk '{print $1}' |grep -v count`
            if [ "$has_version" == '1' ]
            then
                echo $version 'already update !!!! not need update'
                exit 8
            fi
        fi 
    done
}

function check_cpu_mem(){
    #check cpu
    cpu=`cat /proc/cpuinfo |grep "processor"|wc -l`
    mem=`free -g |sed -n '2,2p' |awk '{print $2}'`
    if [ "$cpu" -gt '2' ]
    then
        echo "cpu ok"
        if [ "$mem" -gt '8' ]
        then
            echo "mem is ok"
        else
            echo "Memory less than 8G内存少于8g"
            echo "Please increase the memory to 8g or more请增加内存到8g及以上"
            exit 8
        fi
    else
        echo "CPU Number of cores is"$cpu"! Please add more CPU cores than dual cores增加双核及以上"
        echo "Please add CPU to dual core or above请增加cpu到双核及以上"
        exit 8
    fi
}



# check_cpu_mem
# check_version
# update_clr
# update_PersonnelManage
update_sql
# if [ $? == '0' ]
# then
#     cd $sh_path
#     #get app_name
#     app_name=`pwd |rev| cut -d '/' -f 1 | rev`
#     # get version
#     version=`find ../ -name *$app_name*.zip |cut -d '/' -f2 |cut -d '.' -f1 |awk -F $app_name '{print $1}'`
#     encryption_passwd=`cat $PersonnelManage_app/webapps/PersonnelManage/WEB-INF/classes/system.properties |grep '^password' |awk -F '=' '{print $2}'`
#     for i in $encryption_passwd
#     do
#         passwd=`java -jar $sh_path/tools/SM4Jar.jar D $i |awk -F '：' '{print $2}'`
#         mysql -uroot -p$passwd -e "exit";
#         if [ $? == '0' ]
#         then
#             mysql -uroot -p$passwd -e "update PersonnelManage.t_versions_file set state = '1' where version = '$version';"
#         fi 
#     done
# fi












